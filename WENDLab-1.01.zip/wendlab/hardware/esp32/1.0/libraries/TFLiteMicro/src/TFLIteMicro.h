/*
 * SPDX-FileCopyrightText: 2023 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */
// This header file is kept to avoid Invalid library error prints while compiling TFLite Micro examples.
